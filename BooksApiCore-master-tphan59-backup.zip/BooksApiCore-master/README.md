# BooksApiCore
.NET Core 3.1 LTS with MongoDb, Not included Frontend
